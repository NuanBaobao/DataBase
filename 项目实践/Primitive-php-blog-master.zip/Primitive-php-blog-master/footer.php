<head>
    <link rel="stylesheet" type="text/css" href="./css/footer.css">
</head>
<div class="foot">
    <footer>
        <div id="footer" >
            <div class="copy-info">
                <p>Copyright © 2020
                    <a href="#" target="_blank">萌ICP备</a>
                    <a href="#" target="_blank">20200608号</a>
                    <br>Designed by 微信公众号1024黑
                </p>
            </div>
        </div>
    </footer>
</div>
