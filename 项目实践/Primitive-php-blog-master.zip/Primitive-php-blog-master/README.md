## 项目介绍
**本项目不可用于任何商业活动，仅可用于学习用途**

**UI来源** 
- https://github.com/xb2016/kratos-pjax
- 特别感谢大佬的UI为我期末交作业节省不少时间

**演示站点**
- https://lab.cooleryue.cn/phpblog

**项目截图**

![image](https://raw.githubusercontent.com/5261314/Primitive-php-blog/master/images/1.png)
![image](https://raw.githubusercontent.com/5261314/Primitive-php-blog/master/images/2.png)
![image](https://raw.githubusercontent.com/5261314/Primitive-php-blog/master/images/3.png)
![image](https://raw.githubusercontent.com/5261314/Primitive-php-blog/master/images/4.png)
![image](https://raw.githubusercontent.com/5261314/Primitive-php-blog/master/images/5.png)
![image](https://raw.githubusercontent.com/5261314/Primitive-php-blog/master/images/6.png)
![image](https://raw.githubusercontent.com/5261314/Primitive-php-blog/master/images/7.png)

**完整源码**
- https://github.com/5261314/phpblog/releases

**注意事项**
- 由于未对提交的字段进行过滤，为避免sql注入等恶意攻击，请勿轻易部署到服务器

- 有空再补充详细点
