<?php
//    require("./header.php");
    require("./main.php");
    require("./footer.php");
 ?>
 <!DOCTYPE html>
 <html>
 <head>
     <title>个人博客系统</title>
 </head>
 </html> 
