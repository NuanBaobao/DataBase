<head>
    <link rel="stylesheet" type="text/css" href="./css/footer.css">
</head>
<div class="foot">
    <footer>
        <div id="footer" >
            <div class="copy-info">
                <p>
                    <a href="https://www.sdu.edu.cn/" target="_blank">山东大学</a>
                    <a href="https://www.cs.sdu.edu.cn/" target="_blank">计算机科学与技术学院</a>
                    <br>@数据库系统概念课程设计出品
                </p>
            </div>
        </div>
    </footer>
</div>
