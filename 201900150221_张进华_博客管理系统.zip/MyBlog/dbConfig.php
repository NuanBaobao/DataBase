<?php
const HOST = 'localhost';
const USER = 'root';
const PASS = '130727';
const DBNAME = 'myblog';

